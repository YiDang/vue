// export const prefix='/api'
var prefix = ''
// var prefix = '/api' 
export {prefix}